#include "game.h"
#include "main.h"

void display_cristals(uint8_t width, uint8_t height, uint8_t *cristals)
{
    puts("\r\n### Grid ###\r\n");
    for (int y = 0; y < height; y++)
    {
        for (int x = 0; x < width; x++)
        {
            uint8_t nb_cristals = cristals[x + y * width];
            if (nb_cristals)
                putchar('0' + nb_cristals);
            else
                putchar(' ');
        }
        puts("\r\n");
    }
    puts("### End Grid ###\r\n");
}

void init_game(unsigned int seed, uint8_t *nb_trucks,
               uint8_t *width, uint8_t *height, uint8_t *cristals)
{
    char str[32];
    uint8_t x, y;
    srand(seed);
    *nb_trucks = rand() % (MAX_NB_TRUCKS - 1) + 1;
    *width = rand() % (MAX_WIDTH - 10) + 10;
    *height = rand() % (MAX_HEIGHT - 10) + 10;
    for (y = 0; y < *height; y++)
        for (x = 0; x < *width; x++)
        {
            uint8_t nb_cristals = rand() % 5;
            if (nb_cristals < 3)
                cristals[x + y * *width] = nb_cristals;
            else
                cristals[x + y * *width] = 0;
        }
    puts("trucks: ");
    puts(itoa(*nb_trucks, str, 10));
    puts("\r\nwidth: ");
    puts(itoa(*width, str, 10));
    puts("\r\nheight: ");
    puts(itoa(*height, str, 10));
    display_cristals(*width, *height, cristals);
    puts("\r\nStart!\r\n");
}
