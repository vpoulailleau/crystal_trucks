#ifndef GAME_H_
#define GAME_H_

#include <stdint.h>

#define MAX_NB_TRUCKS (9)
#define MAX_WIDTH (30)
#define MAX_HEIGHT (20)

void init_game(
    unsigned int seed, uint8_t *nb_trucks,
    uint8_t *width, uint8_t *height, uint8_t *cristals);
void display_cristals(uint8_t width, uint8_t height, uint8_t *cristals);

#endif /* GAME_H_ */
